import{j as t}from"./index-DXa1z8xM.js";const n=()=>t.jsx("div",{className:"p-8 text-center text-muted-foreground",children:"Artist not found."});export{n as notFoundComponent};
