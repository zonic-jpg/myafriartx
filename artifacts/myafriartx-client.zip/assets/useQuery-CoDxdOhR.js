import{u as r,Q as u}from"./useBaseQuery--PUYF2Qg.js";function a(e,s){return r(e,u)}export{a as u};
