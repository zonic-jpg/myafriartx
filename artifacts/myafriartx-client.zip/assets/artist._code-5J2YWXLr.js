import{j as t}from"./index-YWk2vuVb.js";const n=()=>t.jsx("div",{className:"p-8 text-center text-muted-foreground",children:"Artist not found."});export{n as notFoundComponent};
