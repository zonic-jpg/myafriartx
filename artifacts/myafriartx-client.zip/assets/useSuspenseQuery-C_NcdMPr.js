import{u as r,Q as u,d as s}from"./useBaseQuery-BJTirMLi.js";function t(e,a){return r({...e,enabled:!0,suspense:!0,throwOnError:s,placeholderData:void 0},u)}export{t as u};
