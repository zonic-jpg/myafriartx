const t="/assets/artist-default-BGFszt32.jpg";export{t as a};
