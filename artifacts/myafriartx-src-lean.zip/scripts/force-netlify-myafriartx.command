#!/bin/bash
set -euo pipefail
export PATH="$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"
ROOT="/Users/olufemiadeagbo/Downloads/artstage-8"
cd "$ROOT"
TOKEN="$(python3 -c "import json;print(json.load(open('$HOME/Library/Preferences/netlify/config.json'))['users']['69d9d210366e2998422ec62d']['auth']['token'])")"
export NETLIFY_AUTH_TOKEN="$TOKEN"
export NETLIFY_SITE_ID="7717c70f-3e72-444c-b7c0-9d96f705f60c"

echo "==> Build SPA (base /)"
rm -rf dist
npx vite build --config vite.config.netlify.ts
node scripts/prepare-netlify-client.mjs
# Ensure stable /media fallbacks + og-image ship with the client
mkdir -p dist/client/media
cp -f public/media/* dist/client/media/ 2>/dev/null || true
cp -f public/og-image.png dist/client/og-image.png 2>/dev/null || true
cp -f public/_redirects dist/client/_redirects

echo "==> Digest deploy"
node scripts/netlify-digest-deploy.mjs dist/client | tee /tmp/myafriartx-deploy.json

echo "==> Verify"
ASSET=$(python3 -c "import re;html=open('dist/client/index.html').read();m=re.search(r'/assets/index-[^\" ]+\.js',html);print(m.group(0) if m else '')")
for i in $(seq 1 24); do
  HC=$(curl -s -o /tmp/mafx.html -w '%{http_code}' -L "https://myafriartx.netlify.app/" || echo 000)
  if [[ "$HC" == "200" ]]; then
    if [[ -n "$ASSET" ]] && grep -q "$ASSET" /tmp/mafx.html 2>/dev/null; then
      echo "LIVE OK attempt $i HTTP=$HC asset=$ASSET"
      exit 0
    fi
    if grep -q 'myafriartx-auth-2\|Discover African art\|/media/pane-' /tmp/mafx.html 2>/dev/null; then
      echo "LIVE OK attempt $i HTTP=$HC (content match)"
      exit 0
    fi
  fi
  echo "wait $i HTTP=$HC"; sleep 5
done
echo "VERIFY FAILED"; exit 1
