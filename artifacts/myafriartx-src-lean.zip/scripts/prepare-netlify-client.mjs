#!/usr/bin/env node
/** Copy SPA shell + redirects into dist/client after vite.config.netlify.ts build. */
import { writeFileSync, existsSync, readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const client = join(root, "dist/client");
const shell = join(client, "_shell.html");

if (!existsSync(shell)) {
  console.error("Missing dist/client/_shell.html — run: npx vite build --config vite.config.netlify.ts");
  process.exit(1);
}

/** TanStack Start can emit NUL bytes in match ids — they break inline boot scripts. */
const shellBuf = readFileSync(shell);
const nulls = shellBuf.filter((b) => b === 0).length;
const clean = shellBuf.toString("utf8").replace(/\0/g, "");
if (nulls) console.log("stripped", nulls, "NUL byte(s) from _shell.html");

for (const name of ["index.html", "404.html", "_shell.html"]) {
  writeFileSync(join(client, name), clean);
  console.log("OK ", name);
}

writeFileSync(
  join(client, "_redirects"),
  ["/auth    /login   302", "/auth/*  /login   302", "/*    /index.html   200", ""].join("\n"),
);
console.log("OK  _redirects");
console.log("Netlify client ready:", client);
